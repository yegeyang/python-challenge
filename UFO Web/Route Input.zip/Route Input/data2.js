var dataSet = [
     {
      rt: "1",
      rtnm: "Bronzeville/Union Station",
      rclr: "#336633",
      rtdd: "1"
     }, 
     {
      rt: "11",
      rtnm: "King Drive",
      rclr: "#009900",
      rtdd: "2"
     },
     {
      rt: "206",
      rtnm: "bMuseum of S & I",
      rclr: "#cc66ff",
      rtdd: "3"
      }
    ];